% PROJECT: Secure Audio Communication (DSSS + BPSK + XOR)
% AKSHAY (BT23ECE050)
% VAIBHAV (BT23ECE051)
% RAHUL GURJAR (BT23ECE061)

%% 1. Initialization
clear;
clc;
close all;
disp('Project Simulation Started (DSSS + AWGN Version)...');

%% 2. Parameters
PCM_bits = 8;        % 8-bit PCM
SF = 10;           % Spreading Factor (DSSS)
snr_dB = 12;         % SNR in dB (Noise level)

%% 3. TRANSMITTER (TX)
% Step 3.1: Audio Input
filename = 'myvoice.wav';  
try
    [y, Fs] = audioread(filename);
    disp('1. Your audio file "myvoice.wav" loaded.');
catch
    disp('ERROR: Audio file "myvoice.wav" nahi mili.');
    disp('Check karo ki file same folder me hai.');
    return; % Code rok do
end

% Convert Stereo to Mono
if size(y, 2) == 2
    disp('Stereo audio detected. Converting to mono.');
    y = y(:, 1); % Use only left channel
end

% Normalize
y = y / max(abs(y)); 
t1 = (0:length(y)-1)/Fs; 
disp(['Processing complete audio of length: ', num2str(length(y)), ' samples.']);

% Step 3.2: PCM (A/D Conversion)
pcm_samples = uint8((y + 1) * 127.5); 
binary_char_matrix = dec2bin(pcm_samples, PCM_bits);
binary_numeric_matrix = binary_char_matrix - '0'; 
data_stream = reshape(binary_numeric_matrix', [], 1);
disp('2. PCM Encoding Done.');

% Step 3.3: Encryption (XOR)
key = randi([0 1], length(data_stream), 1);
encrypted_stream = xor(data_stream, key);
disp('3. XOR Encryption Done.');

% Step 3.4: BPSK Modulation
bpsk_symbols = (encrypted_stream * 2) - 1; % 0 -> -1, 1 -> +1
disp('4. BPSK Modulation Done.');

% Step 3.5: DSSS Spreading
pn_sequence = (randi([0 1], SF, 1) * 2) - 1;
spread_signal = kron(bpsk_symbols, pn_sequence);
disp('5. DSSS Spreading Done (Signal Hidden).');

%% 4. CHANNEL (AWGN)
% Step 4.1: Add Manual Noise
signal_power = mean(abs(spread_signal).^2);
snr_linear = 10^(snr_dB / 10);
noise_power = signal_power / snr_linear;
noise = sqrt(noise_power) * randn(size(spread_signal));
noisy_signal = spread_signal + noise;
disp('6. Signal sent through Noisy (AWGN) Channel.');

%% 5. RECEIVER (RX)
% Step 5.1: DSSS Despreading (Correlation)
rx_reshaped = reshape(noisy_signal, SF, length(bpsk_symbols));
despread_symbols_vector = (pn_sequence' * rx_reshaped) / SF;
disp('7. DSSS Despreading Done (Signal Recovered).');

% Step 5.2: BPSK Demodulation
received_bits = (despread_symbols_vector > 0)';
disp('8. BPSK Demodulation Done.');

% Step 5.3: Decryption (XOR)
decrypted_stream = xor(received_bits, key);
disp('9. XOR Decryption Done.');

% Step 5.4: D/A Conversion (Back to Audio)
rx_bytes_matrix = reshape(decrypted_stream, PCM_bits, [])';
rx_binary_char_matrix = char(rx_bytes_matrix + '0');
rx_pcm_samples = bin2dec(rx_binary_char_matrix);
output_audio = (double(rx_pcm_samples) / 127.5) - 1;
output_audio = output_audio / max(abs(output_audio)); % Normalize
disp('10. D/A Conversion Done. Playing your audio back...');

% Step 5.5: Play Recovered Audio
sound(output_audio, Fs);

%% 6. PLOTTING RESULTS
figure;

% Plot 1: Input Audio
subplot(3, 1, 1);
plot(t1, y);
title('1. Your Original Audio Signal ("myvoice.wav")');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Plot 2: Output Audio
subplot(3, 1, 2);
t2 = (0:length(output_audio)-1)/Fs;
plot(t2, output_audio);
title('2. Recovered Audio Signal (After Decryption)');
xlabel('Time (s)');
ylabel('Amplitude');
grid on;

% Plot 3: BPSK Constellation
subplot(3, 1, 3);
plot(real(despread_symbols_vector), imag(despread_symbols_vector), 'b.'); 
title('3. BPSK Constellation (After Despreading)');
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');
grid on;
axis([-2 2 -2 2]); 

disp('Simulation Complete. Check the plots.');