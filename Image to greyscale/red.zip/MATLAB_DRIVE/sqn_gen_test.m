clc
clear all
close all
n_max=100;
n_max_rang=n_max/2;
n=-n_max:1:n_max;
lenght_of_n=length(n);
limits_of_n_display=-n_max_rang:1:n_max_rang;
lower_n_display_index=n_max_rang+1;
upper_n_display_index=lower_n_display_index+n_max;

No=0;
No_2=15; % delay by some different amount allowd to be maximun of n/2
alpha=0.5;
N=15;
M=3;
Ng=5;
amp=1;
flag_sqn_is_fliped=0;

type_of_sqn=10;

[x_n] = digital_sqn_gen(type_of_sqn, n, lenght_of_n, No, alpha, Ng, amp, N, M);
stem(n(1, lower_n_display_index:upper_n_display_index), x_n(1, lower_n_display_index:upper_n_display_index))
xlabel("n")
ylabel("x(n)")
%filp the sqn
[x_n_filped] = flip_the_sqn(x_n,lenght_of_n);
% x_n_filped=zeros(1, lenght_of_n);
% for ii=1:1:lenght_of_n
%     x_n_filped(ii)=x_n(lenght_of_n-ii+1);
% end

%delay the sqn
% x_delayed=zeros(1, lenght_of_n);
% if(flag_sqn_is_fliped==0)
%     for ii=1:1:lenght_of_n
%         if( (n(ii)-No_2)<-n_max)
%             x_delayed(ii)=0;
%         elseif((n(ii)-No_2)>=-n_max && (n(ii)-No_2)<=n_max)
%             x_delayed(ii)=x_n(ii-No_2);
%         elseif((n(ii)-No_2)>n_max)
%              x_delayed(ii)=0;
%         end
%     end
% 
% elseif(flag_sqn_is_fliped==1)
%     for ii=1:1:lenght_of_n
%         if( (n(ii)+(No_2)) < -n_max)
%             x_delayed(ii)=0;
%         elseif( (n(ii)+(No_2)) >=-n_max && (n(ii)+(No_2) )<=n_max)
%             x_delayed(ii)=x_n_filped(ii+No_2);
%         elseif((n(ii)+(No_2))>n_max)
%              x_delayed(ii)=0;
% 
%         end
%     end
% end

% [x_delayed] = delay_the_sqn(x_n, n, lenght_of_n, n_max, No_2, 0);
% 
% 
% 
% subplot(3,1,1),stem(n(1, lower_n_display_index:upper_n_display_index), x_n(1, lower_n_display_index:upper_n_display_index))
% xlabel("n")
% ylabel("x(n)")
% 
% subplot(3,1,2),stem(n(1, lower_n_display_index:upper_n_display_index), x_n_filped(1, lower_n_display_index:upper_n_display_index))
% xlabel("n")
% ylabel("fliped version of x(n)")
% 
% subplot(3,1,3),stem(n(1, lower_n_display_index:upper_n_display_index), x_delayed(1, lower_n_display_index:upper_n_display_index))
% xlabel("n")
% ylabel("delayed version of x(n)")