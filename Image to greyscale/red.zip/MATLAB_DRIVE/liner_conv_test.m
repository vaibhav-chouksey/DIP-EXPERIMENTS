clc
clear all
close all

n_max=50;
n_max_rang=n_max/2;
n=-n_max:1:n_max;
lenght_of_n=length(n);

n_x=(-n_max/2):1:(n_max/2);
lenght_of_nx=length(n_x);

limits_of_n_display=-n_max_rang:1:n_max_rang;
length_of_n_for_display=length(limits_of_n_display);
lower_n_display_index=n_max_rang+1;
upper_n_display_index=lower_n_display_index+n_max;

No=0;
No_2=0; % delay by some different amount allowd to be maximun of n/2
alpha=0.5;
N=16;
M=3;
Ng=5;
amp=1;
flag_sqn_1_is_fliped=0;
flag_sqn_2_is_fliped=0;

type_of_sqn=4;
[h_n] = digital_sqn_gen(type_of_sqn, n, lenght_of_n, No, alpha, Ng, amp, N, M);
subplot(6,1,1),stem(n(1, lower_n_display_index:upper_n_display_index),h_n(1, lower_n_display_index:upper_n_display_index));
xlabel("n")
ylabel("h(n)")

type_of_sqn=2;
[x_n_1] = digital_sqn_gen(type_of_sqn, n, lenght_of_n, No, 2, Ng, amp, N, M);
[x_n] = flip_the_sqn(x_n_1,lenght_of_n);
subplot(6,1,2),stem(n(1, lower_n_display_index:upper_n_display_index),x_n(1, lower_n_display_index:upper_n_display_index));
xlabel("n")
ylabel("x(n)")

%------Start of Convolution------------------------------
%------Step.1  filp the sqn-----------------------------
[x_n_fliped] = flip_the_sqn(h_n,lenght_of_n);
subplot(6,1,3),stem(n(1, lower_n_display_index:upper_n_display_index),x_n_fliped(1, lower_n_display_index:upper_n_display_index));
xlabel("n")
ylabel("h(-n)")


flag_sqn_1_is_fliped=1;
subplot(6,1,4),stem(n(1, lower_n_display_index:upper_n_display_index),x_n(1, lower_n_display_index:upper_n_display_index));
xlabel("n")
ylabel("x(n)")
y_n=ones(lenght_of_n)*NaN;
for ii=1:length_of_n_for_display
    %---Step. 2 delay the filped sqn-----------------
    [x_fliped_delayed] = delay_the_sqn(x_n_fliped, n, lenght_of_n, n_max, limits_of_n_display(ii), flag_sqn_1_is_fliped);
    subplot(6,1,5),stem(n(1, lower_n_display_index:upper_n_display_index),x_fliped_delayed(1, lower_n_display_index:upper_n_display_index));
    xlabel("k")
    ylabel("h(k-n)")

    %--Step. 3 Multiple the sqn
    temp=x_n.*x_fliped_delayed;
    y_n(ii)=sum(temp);

    subplot(6,1,6),stem(n, y_n )
    xlabel("n")
    ylabel("y(n)")
    pause(0.1)
end


