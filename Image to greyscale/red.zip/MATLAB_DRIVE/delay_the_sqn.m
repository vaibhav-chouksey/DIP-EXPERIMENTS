function [x_delayed] = delay_the_sqn(x_n, n, lenght_of_n, n_max, No_2, flag_sqn_is_fliped)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
x_delayed=zeros(1, lenght_of_n);
if(flag_sqn_is_fliped==0)
    for ii=1:1:lenght_of_n
        if( (n(ii)-No_2)<-n_max)
            x_delayed(ii)=0;
        elseif((n(ii)-No_2)>=-n_max && (n(ii)-No_2)<=n_max)
            x_delayed(ii)=x_n(ii-No_2);
        elseif((n(ii)-No_2)>n_max)
             x_delayed(ii)=0;
        end
    end

elseif(flag_sqn_is_fliped==1)
    for ii=1:1:lenght_of_n
        if( (n(ii)-(No_2)) < -n_max)
            x_delayed(ii)=0;
        elseif( (n(ii)-(No_2)) >=-n_max && (n(ii)-(No_2) )<=n_max)
            x_delayed(ii)=x_n(ii-No_2);
        elseif((n(ii)-(No_2))>n_max)
             x_delayed(ii)=0;

        end
    end
end
end