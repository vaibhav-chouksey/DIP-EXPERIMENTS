function [x_n_filped] = flip_the_sqn(x_n,lenght_of_n)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
x_n_filped=zeros(1, lenght_of_n);
for ii=1:1:lenght_of_n
    x_n_filped(ii)=x_n(lenght_of_n-ii+1);
end
end