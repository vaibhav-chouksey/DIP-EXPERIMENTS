T = 0.01;
Fs = 1/T;
t = 0:T:1;   
f = 3;
noise_level = 0.5;

signal = sin(2*pi*f*t);
noise = noise_level * randn(size(t));
noisy_sign = signal + noise;

figure;
subplot(2,1,1);
plot(t, noisy_sign);
title('Noisy Sine Signal');
xlabel('Time (s)');
ylabel('Amplitude');

cutoff_freq = 60;
[b, a] = butter(6, cutoff_freq/(Fs/2), 'low');
denoised_sign = filter(b, a, noisy_sign);

subplot(2,1,2);
plot(t, denoised_sign);
title('Denoised Sine Signal');
xlabel('Time (s)');
ylabel('Amplitude');
