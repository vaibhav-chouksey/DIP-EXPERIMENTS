clear all;
close all;
clc;

N = 40;

h=zeros(1,40);
%nh =[-19,-18,-17,-16,1]
nh=-19:1:20;

x = zeros(1, N);  
x(11) = 1; 

y = zeros(1, N);

for 
      y(n) = x(n) + 2*x(n-1) + 3*y(n-3) + 0.5*y(n-2) + y(n-1);
end

%y[n] = 3y[n-3]+0.5y[n-2]+y[n-1] = x[n] + 2x[n-1]