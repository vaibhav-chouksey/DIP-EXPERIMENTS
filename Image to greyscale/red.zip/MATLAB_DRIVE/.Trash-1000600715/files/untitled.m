clc;
clear;
close all;

x = [1 3 5 7];
h = [2 4 6 8];
N = 4;

% Zero-padding to match length N
x = [x zeros(1, N - length(x))];
h = [h zeros(1, N - length(h))];

y = zeros(1, N);

for n = 1:N
    for k = 1:N
        ind = mod(n - k + N, N) + 1; % Corrected index calculation
        y(n) = y(n) + x(k) * h(ind);
    end
end

disp('Circular Convolution Result:');
disp(y);

n = 0:N-1;

subplot(3,1,1);
stem(n, x, 'filled');
xlabel('n -->');
ylabel('Amplitude -->');
title('x(n)');

subplot(3,1,2);
stem(n, h, 'filled');
xlabel('n -->');
ylabel('Amplitude -->');
title('h(n)');

subplot(3,1,3);
stem(n, y, 'filled');
xlabel('n -->');
ylabel('Amplitude -->');
title('Circular Convolution y(n)');
clc;
clear;
close all;
t = 0:0.01:10; 
A = 1; 
w = 2 * pi * 1; 
phi = 0; 
k = 5; 
n = 0:0.1:10; 
alpha = 0.5; 
y_discrete_sine = A * sin(w * n);
y_exp = exp(alpha * n);
y_step = ones(size(n)); 
y_sine = A * sin(w * t + phi);
y_ramp = k * t;
y_triangular = sawtooth(2 * pi * 0.5 * t, 0.5);
y_increasing_exp = exp(alpha * n);
y_decreasing_exp = exp(-alpha * n);
subplot(3,3,1);
plot(t, y_sine, 'b');
grid on;
title('Sine Wave');
xlabel('Time');
ylabel('Amplitude');
subplot(3,3,2);
plot(t, y_ramp, 'r');
grid on;
title('Ramp Signal');
xlabel('Time'); 
ylabel('Amplitude');
subplot(3,3,3);
plot(t, y_triangular, 'g');
grid on;
title('Triangular Wave');
xlabel('Time'); 
ylabel('Amplitude');
subplot(3,3,4);
plot(n, y_increasing_exp, 'm');
grid on;
title('Increasing Exponential');
xlabel('Time'); 
ylabel('Amplitude');
subplot(3,3,5);
plot(n, y_decreasing_exp, 'c');
grid on;
title('Decreasing Exponential');
xlabel('Time'); 
ylabel('Amplitude');
subplot(3,3,6);
stem(n, y_discrete_sine, 'b', 'filled');
grid on;
title('Discrete Sine Wave');
xlabel('Samples (n)');
ylabel('Amplitude');
subplot(3,3,7);
stem(n, y_exp, 'r', 'filled');
grid on;
title('Exponential Signal');
xlabel('Samples (n)');
ylabel('Amplitude');
figure;
stem(n, y_step, 'k', 'filled');
grid on;
title('Unit Step Signal');
xlabel('Samples (n)'); 
ylabel('Amplitude');
