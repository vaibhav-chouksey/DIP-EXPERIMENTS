clear all;
close all;
clc;
nt = 0:0.01:1;
fs = 1/0.01;
f=3;
X = 1*sin(2*pi*f*nt);
D=length(X);
y = awgn(X,5);
%adding noise 5=SNR
F1 = fft(X);
xfft=fs.*(0:D-1)/D;
stem(xfft,abs(F1),'b','MarkerSize',6);
title('orignal signal');
xlabel('SAmples');
ylabel('Amplitude');
figure()
F2 = fft(y);
xfft = fs.*(0:D-1)/D;
stem(xfft,abs(F2),'r','MarkerSize',6);