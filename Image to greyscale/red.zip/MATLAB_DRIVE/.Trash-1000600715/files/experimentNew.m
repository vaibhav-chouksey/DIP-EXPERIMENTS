clear all;
close all;
clc;


num=[1,1];
den = [3,2,1];
fs=1000;
ts=1/fs;
h=tf(num,den,ts,'variable','z');
pzmap(h);
zgrid
