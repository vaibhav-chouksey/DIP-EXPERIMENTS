clear all;
close all;
clc;


N = 4;
x1 = [1 2 3 4];
x2 = [5 6 7 8];


X1 = N_Point_dft(N, x1);
X2 = N_Point_dft(N, x2);


y_freq = X1 .* X2;


y_circ = circ_conv(x1, x2);


Idft = exp(1i * 2 * pi * (0:N-1)' * (0:N-1) / N) / N;
y_time = Idft * y_freq;


disp(y_circ);
disp(y_time);


function y = N_Point_dft(N, x)
    s = zeros(N, N);
    for k = 0:N-1
        for n = 0:N-1
            s(k+1, n+1) = exp(-1i * 2 * pi * k * n / N);
        end
    end
    y = s * x';  
end


function y = circ_conv(x1, x2)
    N = length(x1);
    y = zeros(1, N);  
    for n = 1:N
        for k = 1:N
            ind = mod(n - k, N) + 1;
            y(n) = y(n) + x1(k) * x2(ind);
        end
    end
end


