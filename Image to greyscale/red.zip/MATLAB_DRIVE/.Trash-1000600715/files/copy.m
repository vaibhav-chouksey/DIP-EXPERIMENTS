% Define time vector
t = -1:0.001:1;  % Time from -1 to 1 seconds with small steps

% Create a narrow pulse to approximate the impulse
impulse_signal = (t == 0);  % Impulse at t = 0

% Plot the impulse signal
figure;
stem(t, impulse_signal, 'Marker', 'o');
title('Continuous-Time Impulse Signal');
xlabel('Time (seconds)');
ylabel('Amplitude');
