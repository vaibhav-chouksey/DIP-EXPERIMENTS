clear all
close all

n_max=500;
n_max_rang=n_max/2;
n=-n_max:1:n_max;
lenght_of_n=length(n);
limits_of_n_display=-n_max_rang:1:n_max_rang;
lenght_n_display=length(limits_of_n_display);
lower_n_display_index=n_max_rang+1;
upper_n_display_index=lower_n_display_index+n_max;

omega_step_size=0.0001*pi;
omega_x=-1*pi:omega_step_size:1*pi;
length_of_omega_x=length(omega_x);

No=0;
No_2=0; % delay by some different amount allowd to be maximun of n/2
alpha=0.8;
N=20;
M=5;
NG=30;
amp=1;


[g_n] = digital_sqn_gen(6, n,...
    lenght_of_n, No, alpha, NG, amp, N, M);

[cos_n] = digital_sqn_gen(7, n,...
    lenght_of_n, No, alpha, NG, amp, N, M);

x_n=g_n.*cos_n;

for ii=1:length_of_omega_x
    temp1=exp(-1j*omega_x(ii).*n);
    temp2=g_n.*temp1;
    G_omega(ii)=sum(temp2);
end

for ii=1:length_of_omega_x
    temp1=exp(-1j*omega_x(ii).*n);
    temp2=cos_n.*temp1;
    Cos_omega(ii)=sum(temp2);
end

for ii=1:length_of_omega_x
    temp1=exp(-1j*omega_x(ii).*n);
    temp2=x_n.*temp1;
    X_omega(ii)=sum(temp2);
end
Mag_G_omega=abs(G_omega);
Angle_G_omega=atan(imag(G_omega)./real(G_omega));

Mag_Cos_omega=abs(Cos_omega);
Angle_Cos_omega=atan(imag(Cos_omega)./real(Cos_omega));


Mag_X_omega=abs(X_omega);
Angle_X_omega=atan(imag(X_omega)./real(X_omega));



subplot(3,1,1),stem(n(1, lower_n_display_index:upper_n_display_index),...
    g_n(1, lower_n_display_index:upper_n_display_index))
xlabel("n")
ylabel("g(n)")

subplot(3,1,2),stem(n(1, lower_n_display_index:upper_n_display_index),...
    cos_n(1, lower_n_display_index:upper_n_display_index))
xlabel("n")
ylabel("cos(\omega_o n)")

subplot(3,1,3),stem(n(1, lower_n_display_index:upper_n_display_index),...
    x_n(1, lower_n_display_index:upper_n_display_index))
xlabel("n")
ylabel("x(n)")

% X_omega_the=ones(1,length_of_omega_x);
% X_omega_phase_angle=zeros(1,length_of_omega_x);

% X_omega_the=1./(sqrt((1+alpha^2)-(2*alpha)*cos(omega_x)));
% X_omega_phase_angle=atan(-alpha*sin(omega_x)./(1-alpha*cos(omega_x)));

% X_omega_the=((1-alpha^2))./(((1+alpha^2)-(2*alpha)*cos(omega_x)));
% X_omega_phase_angle=zeros(1,length(omega_x));

figure, subplot(3,1,1),plot(omega_x/pi, [Mag_G_omega])
xlabel("Normalized Digital Frequency {\it\omega}")
ylabel("{\itG}({\it\omega})")

subplot(3,1,2),plot(omega_x/pi, [Mag_Cos_omega])
xlabel("Normalized Digital Frequency {\it\omega}")
ylabel("{\itCos}({\it\omega})")


subplot(3,1,3),plot(omega_x/pi, [Mag_X_omega])
xlabel("Normalized Digital Frequency {\it\omega}")
ylabel("{\itX}({\it\omega})")
