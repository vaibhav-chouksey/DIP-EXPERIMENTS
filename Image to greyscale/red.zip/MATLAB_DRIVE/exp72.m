% zeros and poles of the transfer function
clear all;
close all;
clc;
fs=1000;
ts=1/fs;
num=[5,4];
den=[2,4,5,6];
h=tf(num,den,ts,'variable','z');
pzmap(h);