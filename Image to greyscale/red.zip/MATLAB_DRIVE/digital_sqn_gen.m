function [x_n] = digital_sqn_gen(type_of_sqn, n, lenght_of_n, No, alpha, NG, amp, N, M)
%my program for digital sqn gen
%   Detailed explanation goes here
% Delta Function type_of_sqn=1
% unit step type_of_sqn=2
% ramp Function type_of_sqn=3
% Rightsided Exponential decay Function type_of_sqn=4
% double Exponential decay Function type_of_sqn=5
% Gate Exponential decay Function type_of_sqn=6
% cosinosodial Exponential decay Function type_of_sqn=7
% sinosodial Exponential decay Function type_of_sqn=8
% sgnum  Function type_of_sqn=9
% sinc  Function type_of_sqn=10

flag_to_start=0;
if(type_of_sqn==1)% Delta Function type_of_sqn=1
    for ii=1:1:lenght_of_n
        if((n(ii)-No)==0)
            x_n(ii)=1;
        else
            x_n(ii)=0;
        end 
    end

elseif(type_of_sqn==2)% unit step type_of_sqn=2
    for ii=1:1:lenght_of_n
        if((n(ii)-No)==0)
            x_n(ii)=1;
            flag_to_start=1;
        elseif( ((n(ii)-No)>0) && flag_to_start==1)
            x_n(ii)=1;
        else
            x_n(ii)=0;
        end 
    end

elseif(type_of_sqn==3)% ramp Function type_of_sqn=3
    for ii=1:1:lenght_of_n
        if((n(ii)-No)==0)
            x_n(ii)=(n(ii)-No);
            flag_to_start=1;
        elseif( ((n(ii)-No)>0) && flag_to_start==1)
            x_n(ii)=(n(ii)-No);
        else
            x_n(ii)=0;
        end 
    end    

elseif(type_of_sqn==4)  % Rightsided Exponential decay Function type_of_sqn=4
    for ii=1:1:lenght_of_n
        if((n(ii)-No)==0)
            x_n(ii)=alpha^(n(ii)-No);
            flag_to_start=1;
        elseif( ((n(ii)-No)>0) && flag_to_start==1)
            x_n(ii)=alpha^(n(ii)-No);
        else
            x_n(ii)=0;
        end 
    end
elseif(type_of_sqn==5) % double Exponential decay Function type_of_sqn=5
    for ii=1:1:lenght_of_n
        if((n(ii)-No)==0)
            x_n(ii)=alpha^(n(ii)-No);
            flag_to_start=1;
        elseif( ((n(ii)-No)>0) && flag_to_start==1)
            x_n(ii)=alpha^(n(ii)-No);
        else
            x_n(ii)=alpha^(-n(ii)-No);
        end 
    end  
elseif(type_of_sqn==6) % Gate Exponential decay Function type_of_sqn=6
    for ii=1:1:lenght_of_n
        if( (n(ii)>= -NG + No) &&  (n(ii)<= NG + No))
            x_n(ii)=1*alpha;
        else
            x_n(ii)=0;
        end 
    end

elseif(type_of_sqn==7) % cosinosodial Exponential decay Function type_of_sqn=7
    for ii=1:1:lenght_of_n
        x_n=amp*cos(2*pi*(M/N).*n);
    end

elseif(type_of_sqn==8) % sinosodial Exponential decay Function type_of_sqn=8
    for ii=1:1:lenght_of_n
        x_n=amp*sin(2*pi*(M/N).*n);
    end

elseif(type_of_sqn==9) % sgnum  Function type_of_sqn=9
    for ii=1:1:lenght_of_n
        if((n(ii)-No)<0)
            x_n(ii)=-1*amp;

        elseif( (n(ii)-No) ==0 )
            x_n(ii)=0;

        else
            x_n(ii)=1*amp;
        end 
    end   
elseif(type_of_sqn==10) % sinc  Function type_of_sqn=10
    for ii=1:1:lenght_of_n
        if(n(ii)==0)
            x_n(ii)=amp;
        else
            x_n(ii)=amp*( (sin(2*pi*(M/N).*n(ii)))/ (2*pi*(M/N).*n(ii)) );
        end 

    end   
else



end





