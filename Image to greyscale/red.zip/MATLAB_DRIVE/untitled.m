clc;
clear all;
close all;

% Define Z-plane grid
re_z = -3:0.1:3;
im_z = -3:0.1:3;
[X, Y] = meshgrid(re_z, im_z);
z_plan = X + 1i * Y;

% Sequence params
n = -50:1:50;
len_n = length(n);
No = 0;
alpha = 0.9;
amp = 1;
M = 1;
N1 = 6;
NG = 5;

% Loop through all 10 types of signals
for type_of_sqn = 1:10
    figure('Name', ['Type ', num2str(type_of_sqn)], 'NumberTitle', 'off');
    
    % Generate signal
    x_n = digital_sqn_gen(type_of_sqn, n, len_n, No, alpha, NG, amp, N1, M);
    
    % --- Time-Domain Plot ---
    subplot(2, 2, 1);
    stem(n, x_n, 'filled');
    xlabel('n'); ylabel('x[n]');
    title(['Signal Type ', num2str(type_of_sqn)]);
    grid on;
    
    % --- Z-transform Surface ---
    z_x = zeros(length(im_z), length(re_z));
    for ii = 1:length(re_z)
        for jj = 1:length(im_z)
            z = z_plan(jj, ii);
            z_x(jj, ii) = abs(sum(x_n .* (z .^ -n))); % Z-transform
        end
    end

    subplot(2, 2, 2);
    surf(X, Y, 20*log10(z_x), 'LineStyle', 'none');
    xlabel('Re(z)'); ylabel('Im(z)');
    title('|Z{X[n]}| in dB');
    colorbar;

    subplot(2, 2, 3);
    mesh(X, Y, 20*log10(z_x));
    xlabel('Re(z)'); ylabel('Im(z)');
    title('|Z{X[n]}| Mesh View');
    colorbar;

    subplot(2, 2, 4);
    imagesc([re_z(1), re_z(end)], [im_z(end), im_z(1)], 20*log10(z_x));
    xlabel('Re(z)'); ylabel('Im(z)');
    title('|Z{X[n]}| Image');
    colorbar;

    % --- Parseval's Relation ---
    [X_omega, omega] = compute_DTFT(x_n, n);
    E_time = sum(abs(x_n).^2);
    E_freq = (1 / (2*pi)) * trapz(omega, abs(X_omega).^2);

    fprintf('\nParseval Check for signal type %d:\n', type_of_sqn);
    fprintf('Time domain energy     = %.6f\n', E_time);
    fprintf('Frequency domain energy= %.6f\n', E_freq);
    fprintf('Difference             = %.6e\n', abs(E_time - E_freq));
end

% ========== Helper Function: DTFT ==========
function [X_omega, omega] = compute_DTFT(x_n, n)
    omega = linspace(-pi, pi, 2048);
    X_omega = zeros(size(omega));
    for k = 1:length(omega)
        X_omega(k) = sum(x_n .* exp(-1j * omega(k) * n));
    end
end

% ========== Include digital_sqn_gen below or ensure it's on path ==========
function [x_n] = digital_sqn_gen(type_of_sqn, n, lenght_of_n, No, alpha, NG, amp, N, M)
    flag_to_start = 0;
    x_n = zeros(1, lenght_of_n);
    switch type_of_sqn
        case 1 % Delta
            x_n = (n == No);
        case 2 % Unit Step
            x_n = double(n >= No);
        case 3 % Ramp
            x_n = max(0, n - No);
        case 4 % Right-sided Exponential
            x_n = (n >= No) .* (alpha .^ (n - No));
        case 5 % Double Exponential
            x_n = alpha .^ abs(n - No);
        case 6 % Gate Exponential
            x_n = ((n >= -NG + No) & (n <= NG + No)) * alpha;
        case 7 % Cosine Exponential
            x_n = amp * cos(2 * pi * M / N * n);
        case 8 % Sine Exponential
            x_n = amp * sin(2 * pi * M / N * n);
        case 9 % Signum
            x_n = amp * sign(n - No);
        case 10 % Sinc
            x_n = zeros(size(n));
            for ii = 1:length(n)
                if n(ii) == No
                    x_n(ii) = amp;
                else
                    x_n(ii) = amp * (sin(2*pi*(M/N)*(n(ii)-No)) / (2*pi*(M/N)*(n(ii)-No)));
                end
            end
        otherwise
            error('Invalid sequence type');
    end
end
