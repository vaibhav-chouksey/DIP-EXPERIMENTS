clc;
clear all;
close all;

%% --- Define Z-plane region ---
re_z = -3:0.1:3;
im_z = -3:0.1:3;
[X, Y] = meshgrid(re_z, im_z);
z_plan = X + 1i * Y;

%% --- Signal Parameters ---
n = -50:1:50;
len_n = length(n);
No = 0;
alpha = 0.9;
A = 1;
M = 1;
N1 = 6;
NG = 5;

%% Choose signal type (1 to 10) ---
type_of_sqn = 2; % Example: Right-sided exponential decay

%% --- Generate the Signal ---
[x_n] = digital_sqn_gen(type_of_sqn, n, len_n, No, alpha, NG, A, N1, M);

%% --- Visualize the signal ---
subplot(2, 2, 1);
stem(n, x_n, 'filled');
xlabel('n'); ylabel('x[n]');
title(['Sequence Type ', num2str(type_of_sqn)]);

%% --- Compute Z-transform over the Z-plane numerically ---
z_x = zeros(length(im_z), length(re_z));
for ii = 1:length(re_z)
    for jj = 1:length(im_z)
        z = z_plan(jj, ii);
        z_x(jj, ii) = abs(sum(x_n .* (z .^ -n))); % Z-transform: sum(x[n] * z^(-n))
    end
end

%% --- Plotting ---
subplot(2, 2, 2);
surf(X, Y, 20*log10(z_x), 'LineStyle', 'none');
xlabel('Re(z)'); ylabel('Im(z)');
title('|Z{X[n]}| in dB (Surface)');
colorbar;

subplot(2, 2, 3);
mesh(X, Y, 20*log10(z_x));
xlabel('Re(z)'); ylabel('Im(z)');
title('|Z{X[n]}| in dB (Mesh)');
colorbar;

subplot(2, 2, 4);
imagesc([re_z(1), re_z(end)], [im_z(end), im_z(1)], 20*log10(z_x));
xlabel('Re(z)'); ylabel('Im(z)');
title('|Z{X[n]}| in dB (Image)');
colorbar;

