Fs = 1000;
t = 0:1/Fs:1-1/Fs;
f = 50;
noisy_signal = sin(2*pi*f*t) + 0.5 * randn(size(t));

[b, a] = butter(6, 60/(Fs/2), 'low');
denoised_signal = filter(b, a, noisy_signal);

plot(t, noisy_signal, t, denoised_signal);
